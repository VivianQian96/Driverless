package edu.msu.qianjiay.driverlesscar;

/**
 * Created by jiayueqian on 28/07/2019.
 */
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;
import java.util.ArrayList;

public class Driverless {
    private int driverlessSize;
    private final Bitmap background;
    private final static float SCALE_IN_VIEW = 0.9f;
    private int marginX;
    private int marginY;
    private float scaleFactor;
    private MyView myview;
    public void setMyView(MyView view) {
        this.myview = view;
    }
    public Driverless(Context context) {

        // Load the checkerboard image
        background =
                BitmapFactory.decodeResource(context.getResources(),
                        R.drawable.park);


    }

    public void draw(Canvas canvas) {
        int wid = canvas.getWidth();
        int hit = canvas.getHeight();

        // Determine the minimum of the two dimensions
        int minDim = wid < hit ? wid : hit;

        driverlessSize = (int) (minDim * SCALE_IN_VIEW);

        // Compute the margins so we center the checker
        marginX = (wid - driverlessSize) / 2;
        marginY = (hit - driverlessSize) / 2;

        scaleFactor = (float)driverlessSize / (float)background.getWidth();



        //if(isDone()){
        canvas.save();
        canvas.translate(marginX, marginY);
        canvas.scale(scaleFactor, scaleFactor);
        canvas.drawBitmap(background, 0, 0, null);
        canvas.restore();
        //}

    }

    public boolean onTouchEvent(View view, MotionEvent event) {
        return true;
    }

}
