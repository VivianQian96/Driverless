package edu.msu.qianjiay.driverlesscar;

/**
 * Created by jiayueqian on 28/07/2019.
 */

public class car {
    private float finalX;
    private float finalY;

    public car(float finalX, float finalY) {
        this.finalX = finalX;
        this.finalY = finalY;

    }
}
